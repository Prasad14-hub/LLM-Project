import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { FadeLoader } from 'react-spinners';
import './styles.css';

const MainComponent = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');
  const [selectedOptions, setSelectedOptions] = useState({
    emailContent: false,
    socialMediaPost: false,
    languageTranslation: false,
  });
  const [isLanguageChecked, setIsLanguageChecked] = useState(false);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const selectRef = useRef(null);

  const url = "http://127.0.0.1:5000";

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setFile(file);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('file-upload').click();
  };

  const handleDropdownChange = (e) => {
    const selectElement = selectRef.current;
    setTimeout(() => {
      selectElement.blur();
    }, 0);
  };

  const handleCheckboxChange = (event) => {
    const { id, checked } = event.target;
    setSelectedOptions((prevOptions) => ({
      ...prevOptions,
      [id]: checked,
    }));
    if (event.target.id === 'translate-spanish') {
      setIsLanguageChecked(event.target.checked);
    }
  };

  const handleTextChange = (event) => {
    setInputText(event.target.value);
  };

  const handleUpload = async (event) => {
    event.preventDefault();
    setLoading(true);
    
    const formData = new FormData();
    if (file) {
      formData.append('file', file);
    }
    formData.append('text', inputText);

    const selectedLanguages = Array.from(document.querySelectorAll('#language-options option:checked')).map(option => option.value);
    formData.append('languages', JSON.stringify(selectedLanguages));

    const selectedAgeGroup = document.getElementById('age-group').value;
    formData.append('ageGroup', selectedAgeGroup);

    try {
      const uploadResponse = await fetch(url + '/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Upload failed.');
      }

      const uploadData = await uploadResponse.json();
      if (!uploadData.filename && !uploadData.text_input) {
        throw new Error('Filename or text not returned.');
      }

      const query = uploadData.filename ? `?filename=${encodeURIComponent(uploadData.filename)}` : `?text_input=${encodeURIComponent(uploadData.text_input)}`;
      const resultResponse = await fetch(`${url}/recreation_result${query}`);

      if (!resultResponse.ok) {
        throw new Error('Fetching recreation result failed.');
      }

      const resultData = await resultResponse.json();
      if (resultData.file_url && resultData.o1 && resultData.o2 && resultData.o3) {
        setLoading(false);
        navigate('/recreation_result', {
          state: {
            fileUrl: resultData.file_url,
            o1: resultData.o1,
            o2: resultData.o2,
            o3: resultData.o3,
            selectedOptions: selectedOptions,
          },
        });
      } else {
        throw new Error('Required data not returned.');
      }
    } catch (error) {
      setLoading(false);
      console.error('Error:', error);
    }
  };

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Creator</h1>
        <div className="upload-box">
          <div className="upload-header">
            {/* <img src="/upload.png" alt="Upload Icon" className="upload-icon-image" /> */}
            <h4 style={{ marginBottom: '5px' }}>Upload Image or Enter Text</h4>
          </div>
          <input
            type="file"
            id="file-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <div className="button-group">
            <button id="browse-btn" onClick={handleBrowseClick} className="glass-button">
              Browse Image
            </button>
            {!file && (
              <button id="upload-btn" onClick={handleUpload} className="glass-button">
                Upload
              </button>
            )}
          </div>
          <input
            type="text"
            id="text-input"
            placeholder="Enter your text here..."
            className="text-input"
            onChange={handleTextChange}
          />
          {file && (
            <>
              <div id="preview">
                <div className="preview-container">
                  <img
                    id="preview-image"
                    src={previewSrc}
                    alt="Image Preview"
                    style={{ maxWidth: '200px', maxHeight: '200px' }}
                  />
                  <div className="file-info-overlay">
                    <div>Name: {fileName}</div>
                    <div>Size: {fileSize}</div>
                  </div>
                </div>
                <div className="checkbox-group">
                  <label>
                    <input type="checkbox" id="email-content" onChange={handleCheckboxChange} /> Email Content
                  </label>
                  <label>
                    <input type="checkbox" id="social-media-post" onChange={handleCheckboxChange} /> Social Media Post
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      id="translate-spanish"
                      onChange={handleCheckboxChange}
                    /> Language Translation
                  </label>
                </div>
                <div className="Dropdowns">
                  <div className="dropdown-group">
                    <select id="age-group" className="dropdown">
                      <option value="">Select Age Group</option>
                      <option value="15-20 (Male)">15-20 (Male)</option>
                      <option value="20-40 (Male)">20-40 (Male)</option>
                      <option value="40-60 (Male)">40-60 (Male)</option>
                      <option value="15-20 (Female)">15-20 (Female)</option>
                      <option value="20-40 (Female)">20-40 (Female)</option>
                      <option value="40-60 (Female)">40-60 (Female)</option>
                    </select>
                  </div>
                  {isLanguageChecked && (
                    <div className="dropdown-group">
                      <select
                        id="language-options"
                        className="dropdown"
                        multiple
                        style={{ marginLeft: '-5px' }}
                        onChange={(e) => handleDropdownChange(e)}
                        ref={selectRef}
                      >
                        <option value="English">English</option>
                        <option value="Spanish">Spanish</option>
                        <option value="French">French</option>
                        <option value="German">German</option>
                        <option value="Chinese">Chinese</option>
                        <option value="Japanese">Japanese</option>
                        <option value="Hindi">Hindi</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>
              <button id="upload-btn" onClick={handleUpload} className="glass-button" style={{ marginBottom: "5px" }}>
                Upload
              </button>
            </>
          )}
          {loading && (
            <div className="loader-container">
              <FadeLoader color="#ffffff" />
              <p>Processing...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainComponent;
