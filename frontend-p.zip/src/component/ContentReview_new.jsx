import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './styles.css';

const ContentReview_new = () => {
  const location = useLocation();
  const { fileUrl, llm_answer, dict, mysrc } = location.state || {};

  const [highlightedText, setHighlightedText] = useState('');

  useEffect(() => {
    highlightSentences();
  }, [llm_answer, dict]);

  const highlightSentences = () => {
    let updatedText = llm_answer;

    Object.keys(dict).forEach((sentence) => {
      const escapedSentence = sentence.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'); // Escape special characters
      const regex = new RegExp(`\\b${escapedSentence}\\b`, 'g');

      // Replace the sentence with highlighted version including tooltip
      updatedText = updatedText.replace(regex, (match) => {
        return `<span class="highlight-yellow tooltip">${match}<span class="tooltiptext">${dict[sentence]}</span></span>`;
      });
    });

    setHighlightedText(updatedText);
  };

  return (
    <div className="main-container">
      <>
        <video className="background-video" autoPlay loop muted>
          <source src="/newBackground.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
        <div className="OcontentOverlay1">
          <div className="left-column1">
            {fileUrl && (
              <div className="image-card1">
                <img src={mysrc} alt="Uploaded Preview" className="preview-image1" />
              </div>
            )}
          </div>
          <div className="right-column1">
            <div className="glass-card1" style={{ fontFamily: 'New', height: '480px', width: '60%', position: 'relative', wordWrap: 'break-word' }}>
              <h2>Information:</h2>
              <pre
                className="text"
                id="llm-answer"
                style={{ maxHeight: '600px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}
                dangerouslySetInnerHTML={{ __html: highlightedText }}
              ></pre>
            </div>
            <div className='newSplit' style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', width: '500px' }}>
              <div className="glass-card1" style={{ fontFamily: 'New', height: '400px', paddingLeft: '10px' }}>
              </div>
            </div>
          </div>
        </div>
      </>
    </div>
  );
};

export default ContentReview_new;
