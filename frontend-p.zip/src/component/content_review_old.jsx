import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import FadeLoader from 'react-spinners/FadeLoader';
import './styles.css';
import DashedProgressBar from './DashedProgressBar';


const ContentReview = () => {
  
  const location = useLocation();
  const { fileUrl, llm_answer, highlightList, wordHover, word, final_table, mysrc } = location.state || {};

  const [tooltip, setTooltip] = useState({ visible: false, content: '', x: 0, y: 0 });
  const [loading, setLoading] = useState(true);
  const [highlightedText, setHighlightedText] = useState('');

  const myurl = fileUrl;

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
      highlightWords();
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const highlightWords = () => {
    let updatedText = llm_answer;

    word.forEach((w) => {
      const span = document.createElement('span');
      if (highlightList.includes(w)) {
        span.classList.add('highlight-green');
      } else {
        span.classList.add('highlight-red');
      }
      span.classList.add('tooltip');
      span.innerHTML = `${w}<span class="tooltiptext">${wordHover[w] || 'Hover content not available'}</span>`;
      const regex = new RegExp(`\\b${w}\\b`, 'g');
      updatedText = updatedText.replace(regex, span.outerHTML);
    });

    setHighlightedText(updatedText);
    console.log(":sdsdssafcsv",updatedText)
    console.log(final_table)
  };
  console.log("-------------------",fileUrl)

  return (
    <div className="main-container">
      {loading ? (
        <div className="loader-container">
          <FadeLoader color="#123abc" loading={loading} size={150} />
        </div>
      ) : (
        <>
          <video className="background-video" autoPlay loop muted>
            <source src="/recreationBackground4.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
          <div className="OcontentOverlay1">
            <div className="left-column1">
              {fileUrl && (
                <div className="image-card1">
                  <img src={mysrc} alt="Uploaded Preview" className="preview-image1" />
                </div>
              )}
            </div>
            <div className="right-column1">
              <div className="glass-card1" style={{ fontFamily: 'New', height: '570px', width: '80%' }}>
                <h2>Information:</h2>
                <pre
                  className="text"
                  id="llm-answer"
                  style={{ maxHeight: '600px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}
                  dangerouslySetInnerHTML={{ __html: highlightedText }}
                ></pre>
              </div>
              <div className='newSplit' style={{display:'flex', flexDirection:'column',justifyContent:'space-between'
 
}}>
              <div className="glass-card1" style={{ fontFamily: 'New', height: '570px', paddingLeft: '20px' }}>
                <h2>Compliance Score:</h2>
                <table>
                  <thead>
                    <tr className="header">
                      <th>Section_name</th>
                      <th>(%)</th>
                    </tr>
                  </thead>
                  <tbody>
                  {Object.keys(final_table).map(key => (
                    <tr key={key}>
                      <td>{key}</td>
                      <td>{final_table[key]}</td>
                    </tr>
                  ))}
                  </tbody>
                </table>
              </div>
              <DashedProgressBar score={88.75} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ContentReview;
