import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import FadeLoader from 'react-spinners/FadeLoader';
import './styles.css';
import DashedProgressBar from './DashedProgressBar';

const ContentReview = () => {
  const location = useLocation();
  const { fileUrl, llm_answer, highlightList, wordHover, word, final_table, mysrc } = location.state || {};

  const [highlightedText, setHighlightedText] = useState('');
  const [complianceTable, setComplianceTable] = useState({
    "Products established name": 0,
    "Quantitative composition": 0,
    "Side effects": 0,
    "Warning": 0,
    "Effectiveness": 0,
    "Adverse reactions": 0,
    "Statement encouraging consumers to report negative side effects to FDA": 0,
    "Language and Readability": 0,
    "Total Compliance": 0
  });
  const [dashScore, setDashScore] = useState(0);

  const myurl = fileUrl;

  useEffect(() => {
    const timer = setTimeout(() => {
      highlightWords();
      calculateComplianceScore();
    }, 0);

    return () => clearTimeout(timer);
  }, []);

  const highlightWords = () => {
    let updatedText = llm_answer;

    word.forEach((w) => {
      const span = document.createElement('span');
      if (highlightList.includes(w)) {
        span.classList.add('highlight-green');
      } else {
        span.classList.add('highlight-red');
      }
      span.classList.add('tooltip');
      span.innerHTML = `${w}<span class="tooltiptext">${wordHover[w] || 'Hover content not available'}</span>`;
      const regex = new RegExp(`\\b${w}\\b`, 'g');
      updatedText = updatedText.replace(regex, span.outerHTML);
    });

    setHighlightedText(updatedText);
  };

  const calculateComplianceScore = () => {
    let updatedTable = { ...complianceTable };
    let avg = 0;

    Object.keys(updatedTable).forEach(key => {
      if (highlightList.includes(key)) {
        updatedTable[key] = 100;
        avg += 100;
      }
    });

    avg = avg / (Object.keys(updatedTable).length - 1); // Subtract 1 for the "Total Compliance" key
    updatedTable["Total Compliance"] = avg;

    setComplianceTable(updatedTable);
    setDashScore(avg);
  };

  return (
    <div className="main-container">
      <>
        <video className="background-video" autoPlay loop muted>
          <source src="/newBackground.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
        <div className="OcontentOverlay1">
          <div className="left-column1">
            {fileUrl && (
              <div className="image-card1">
                <img src={mysrc} alt="Uploaded Preview" className="preview-image1" />
              </div>
            )}
          </div>
          <div className="right-column1">
            <div className="glass-card1" style={{ fontFamily: 'New', height: '480px', width: '60%', position: 'relative', wordWrap: 'break-word' }}>
              <h2>Information:</h2>
              <pre
                className="text"
                id="llm-answer"
                style={{ maxHeight: '600px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}
                dangerouslySetInnerHTML={{ __html: highlightedText }}
              ></pre>
            </div>
            <div className='newSplit' style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', width: '500px' }}>
              <div className="glass-card1" style={{ fontFamily: 'New', height: '400px', paddingLeft: '10px' }}>
                <h2>Compliance Score:</h2>
                <table>
                  <thead>
                    <tr className="header">
                      <th>Section_name</th>
                      <th>(%)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(complianceTable).map(key => (
                      <tr key={key}>
                        <td>{key}</td>
                        <td>{complianceTable[key]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <DashedProgressBar score={dashScore} />
            </div>
          </div>
        </div>
      </>
    </div>
  );
};

export default ContentReview;
