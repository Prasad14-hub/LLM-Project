import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FadeLoader } from 'react-spinners';
import './styles.css';

const BrowseImage = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');
  const [loading, setLoading] = useState(false);

  const url = "http://127.0.0.1:5000";

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setFile(file);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('file-upload').click();
  };

  const handleUpload = async (event) => {
    event.preventDefault();
    if (!file) {
      console.error('No file selected.');
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const uploadResponse = await fetch(url + '/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Upload failed.');
      }

      const uploadData = await uploadResponse.json();
      if (!uploadData.filename) {
        throw new Error('Filename not returned.');
      }

      const query = `?filename=${encodeURIComponent(uploadData.filename)}`;
      const resultResponse = await fetch(`${url}/result${query}`);

      if (!resultResponse.ok) {
        throw new Error('Fetching result failed.');
      }

      const resultData = await resultResponse.json();
      if (resultData.file_url && resultData.llm_answer && resultData.highlightList && resultData.wordHover && resultData.word && resultData.final_table) {
        setLoading(false);
        navigate('/review', {
          state: {
            fileUrl: resultData.file_url,
            llm_answer: resultData.llm_answer,
            highlightList: resultData.highlightList,
            wordHover: resultData.wordHover,
            word: resultData.word,
            final_table: resultData.final_table,
            mysrc: previewSrc
          },
        });
      } else {
        throw new Error('Required data not returned.');
      }
    } catch (error) {
      setLoading(false);
      console.error('Error:', error);
    }
  };

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Review</h1>
        <div className="upload-box">
          <h4 style={{ marginTop: '0px', marginBottom: '5px' }}>Upload Image</h4>
          <label htmlFor="file-upload" className="custom-file-upload">
            <div className="upload-icon"></div>
          </label>
          <input
            type="file"
            id="file-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <button id="browse-btn" onClick={handleBrowseClick} className="glass-button">
            Browse Image
          </button>
          {file && (
            <div id="preview">
              <img
                id="preview-image"
                src={previewSrc}
                alt="Image Preview"
                style={{ maxWidth: '300px', maxHeight: '300px' }}
              />
              <table className="fileinfotable">
                <tbody>
                  <tr>
                    <td>Name:</td>
                    <td id="filename">{fileName}</td>
                  </tr>
                  <tr>
                    <td>Size:</td>
                    <td id="filesize">{fileSize}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
          <button id="upload-btn" onClick={handleUpload} className="glass-button">
            Upload
          </button>
          {loading && (
            <div className="loader-container">
              <FadeLoader color="#ffffff" />
              <p>Processing...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BrowseImage;
