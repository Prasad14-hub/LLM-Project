import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FadeLoader } from 'react-spinners';
import './styles.css';

const BrowseImage_new = () => {
  const navigate = useNavigate();
  const [imageFile, setImageFile] = useState(null);
  const [imageFileName, setImageFileName] = useState('');
  const [imageFileSize, setImageFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');
  const [pdfFiles, setPdfFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const url = "http://127.0.0.1:5000";

  const handleImageFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setImageFileName(file.name);
        setImageFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setImageFile(file);
    }
  };

  const handlePdfFileChange = (event) => {
    const files = Array.from(event.target.files);
    console.log("PDF Files Selected:", files);
    setPdfFiles(files);
  };

  const handleBrowseImageClick = () => {
    document.getElementById('image-upload').click();
  };

  const handleBrowsePdfClick = () => {
    document.getElementById('pdf-upload').click();
  };

  const handleUpload = async (event) => {
    event.preventDefault();

    if (!imageFile) {
      console.error('No image file selected.');
      return;
    }

    if (pdfFiles.length === 0) {
      console.error('No PDF files selected.');
      return;
    }

    setLoading(true);

    const formData = new FormData();
    formData.append('file', imageFile);  // Append the image file as 'file'
    pdfFiles.forEach((pdfFile) => {
      formData.append('pdfs', pdfFile);  // Append each PDF file as 'pdfs'
    });

    try {
      const uploadResponse = await fetch(url + '/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Upload failed.');
      }

      const uploadData = await uploadResponse.json();
      if (!uploadData.filename && (!uploadData.pdfs || uploadData.pdfs.length === 0)) {
        throw new Error('Filename or PDFs not returned.');
      }

      const query = `?filename=${encodeURIComponent(uploadData.filename)}`;
      const resultResponse = await fetch(`${url}/result_new${query}`);

      if (!resultResponse.ok) {
        throw new Error('Fetching result failed.');
      }

      const resultData = await resultResponse.json();
      if (resultData.file_url && resultData.llm_answer && resultData.dict) {
        setLoading(false);
        navigate('/review_new', {
          state: {
            fileUrl: resultData.file_url,
            llm_answer: resultData.llm_answer,
            highlightList: resultData.dict,
            mysrc: previewSrc
          },
        });
      } else {
        throw new Error('Required data not returned.');
      }
    } catch (error) {
      setLoading(false);
      console.error('Error:', error);
    }
  };

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Review New</h1>
        <div className="upload-box">
          <h4 style={{ marginTop: '0px', marginBottom: '5px' }}>Upload Image</h4>
          <label htmlFor="image-upload" className="custom-file-upload">
            <div className="upload-icon"></div>
          </label>
          <input
            type="file"
            id="image-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleImageFileChange}
          />
          <button id="browse-image-btn" onClick={handleBrowseImageClick} className="glass-button">
            Browse Image
          </button>
          {imageFile && (
            <div id="image-preview">
              <img
                id="preview-image"
                src={previewSrc}
                alt="Image Preview"
                style={{ maxWidth: '300px', maxHeight: '300px' }}
              />
              <table className="fileinfotable">
                <tbody>
                  <tr>
                    <td>Name:</td>
                    <td id="filename">{imageFileName}</td>
                  </tr>
                  <tr>
                    <td>Size:</td>
                    <td id="filesize">{imageFileSize}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
          <h4 style={{ marginTop: '10px', marginBottom: '5px' }}>Upload PDFs</h4>
          <label htmlFor="pdf-upload" className="custom-file-upload">
            <div className="upload-icon"></div>
          </label>
          <input
            type="file"
            id="pdf-upload"
            accept=".pdf"
            style={{ display: 'none' }}
            multiple
            onChange={handlePdfFileChange}
          />
          <button id="browse-pdf-btn" onClick={handleBrowsePdfClick} className="glass-button">
            Browse PDFs
          </button>
          {pdfFiles.length > 0 && (
            <div id="pdf-preview">
              <ul>
                {pdfFiles.map((pdfFile, index) => (
                  <li key={index}>{pdfFile.name} ({(pdfFile.size / 1024).toFixed(2)} KB)</li>
                ))}
              </ul>
            </div>
          )}
          <button id="upload-btn" onClick={handleUpload} className="glass-button">
            Upload
          </button>
          {loading && (
            <div className="loader-container">
              <FadeLoader color="#ffffff" />
              <p>Processing...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BrowseImage_new;
