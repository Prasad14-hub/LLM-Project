import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import FadeLoader from 'react-spinners/FadeLoader';
import './styles.css';

const ContentRecreation = () => {
    const navigate = useNavigate();
    const location = useLocation();
    
    const { fileUrl, o1, o2, o3, selectedOptions } = location.state || {};

    useEffect(() => {
        console.log('Selected options:', selectedOptions);
        
    }, [selectedOptions]);

    

    return (
        <div className="main-container">
            
                <>
                    <video className="background-video" autoPlay loop muted>
                        <source src="/newBackground.mp4" type="video/mp4" />
                        Your browser does not support the video tag. 
                    
                    </video>
                    <h1 className="app-title">Marketing Material Compliance - Content Creator</h1>
                    <div className="cardContainer">
                        <div className="cardReview">
                            <h2 className='cardTitle'>Email Content</h2>
                            <p className='cardContent'>
                                <pre className="text" style={{ maxHeight: '1200px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
                                    {o1}
                                </pre>
                            </p>

                        </div>
                        <div className="cardReview">
                            <h2 className='cardTitle'>Social Media Post</h2>
                            <p className='cardContent'>
                            <pre className="text" style={{ maxHeight: '1200px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
                                    {o2}
                                </pre>                            
                                </p>
                        </div>
                        <div className="cardReview">
                            <h2 className='cardTitle'>Language Translation</h2>
                            <p className='cardContent'>
                            <pre className="text" style={{ maxHeight: '1200px', overflowY: 'auto', whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
                                    {o3}
                                </pre>                           
                                 </p>
                        </div>
                    </div>
                </>
            
        </div>
    );
};

export default ContentRecreation;
