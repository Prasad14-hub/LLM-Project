import React from 'react';
import './styles.css';
 
const DashedProgressBar = ({ score }) => {
  const segments = 16; // Number of segments
  const filledSegments = Math.round((score / 100) * segments);
 
  const getSegmentColor = (index) => {
    const startColor = [75,254,75]; // Light green
    const endColor = [0, 77, 0]; // Dark green
 
    const ratio = index / (segments - 1);
    const color = startColor.map((start, i) =>
      Math.round(start + (endColor[i] - start) * ratio)
    );
 
    return `rgb(${color.join(',')})`;
  };
 
  return (
    <div className="progress-bar-container">
      <div className="progress-bar-background">
        {[...Array(segments)].map((_, index) => (
          <div
            key={index}
            className={`progress-bar-segment ${index < filledSegments ? 'filled' : ''}`}
            style={{ backgroundColor: index < filledSegments ? getSegmentColor(index) : '#d3d3d3' }}
          ></div>
        ))}
      </div>
      <p className="progress-bar-score">Overall Score: {score}%</p>
    </div>
  );
};
 
export default DashedProgressBar;