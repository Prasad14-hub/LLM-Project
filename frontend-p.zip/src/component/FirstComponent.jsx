import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css';

const FirstComponent = () => {
  console.log("First Compenet")
    const navigate = useNavigate();

    useEffect(() => {
      console.log("FirstComponent rendered");
    }, []);

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/videoBackground.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <h1 className="app-title">Marketing Material Compliance</h1>
      <div className="cards-containera">
        <div className="card" onClick={()=> navigate("/main")}>
        <img className='logo' src="/Dlogo.png" alt="Logo"/>
          <h2 className='title1'>Content Creator</h2>
        </div>
        <div className="card2" onClick={()=> navigate("/browse")}>
        <img className='logo' src="/mind.png" alt="Logo"/>
          <h2 className='title2'>Content Review</h2>
        </div>
        <div className="card2" onClick={()=> navigate("/browse_new")}>
        <img className='logo' src="/mind.png" alt="Logo"/>
          <h2 className='title2'>Content Review 2</h2>
        </div>
      </div>
    </div>
  );
};

export default FirstComponent;
