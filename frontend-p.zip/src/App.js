
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import MainComponent from './component/MainComponent';
import FirstComponent from './component/FirstComponent';
import ContentRecreation from './component/ContentRecreation';
import BrowseImage from './component/BrowseImage';
import ContentReview from './component/ContentReview';
import 'typeface-maven-pro';
import "@fontsource/lexend"; 
import './App.css';
import ContentReview_new from './component/ContentReview_new';
import BrowseImage_new from './component/BrowseImage_new';

const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<FirstComponent/>}/>
          
          <Route path="/main" element={<MainComponent/>}/>
          <Route path="/browse" element={<BrowseImage/>}/>
          <Route path="/browse_new" element={<BrowseImage_new/>}/>


          <Route path="/recreation_result" element={<ContentRecreation/>}/>
          <Route path="/review" element={<ContentReview/>}/>
          <Route path="/review_new" element={<ContentReview_new/>}/>



        </Routes>
      </div>
    </Router>
  );
};

export default App;